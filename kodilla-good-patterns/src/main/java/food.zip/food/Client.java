package food;

public class Client {


    String addrees ;
    String name;
    String surname;



    public Client(String addrees, String name, String surname) {
        this.addrees = addrees;
        this.name = name;
        this.surname = surname;
    }
}
