package food;

public class NoProductException extends  Exception{

    public NoProductException(String message) {
        super(message);
    }
}
